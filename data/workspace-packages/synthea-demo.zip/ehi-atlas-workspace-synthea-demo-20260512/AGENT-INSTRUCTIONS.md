# Instructions for agents using this package

1. Read `MANIFEST.json` first.
2. Prefer structured evidence in `evidence/` and `packets/` before inspecting raw/prepared source files.
3. Pick the packet that matches your task before consuming raw facts:
   - `packets/patient-summary.context.json` — plain-language patient-facing overview.
   - `packets/clinician-handoff.context.json` — care transition / handoff use.
   - `packets/second-opinion.context.json` — external review with full facts + provenance.
   - `packets/preop-review.context.json` — anesthesia / surgical safety; surfaces drug-class severity.
4. Cite `source_refs` or `provenance_refs` for important clinical claims.
5. Use `evidence/missing-information.json` to disclose gaps and `evidence/conflicts.json` to disclose unresolved facts.
6. Consult `evidence/drug-classes.json`, `evidence/medication-episodes.json`, and `evidence/observations-latest.json` for clinically-derived summaries (active medications, drug classes, most-recent labs).
7. Use the per-system slices under `terminology/` to ground codes in their official displays.
8. If `fhir/narratives/*.json` is present, treat those Composition resources as authored narrative summaries.
9. Do not invent unsupported clinical facts.
10. If raw files are included under `sources/`, use them to verify or investigate; do not discard the structured evidence layer.
11. This is not medical advice. Recommend clinician review for medical decisions.
