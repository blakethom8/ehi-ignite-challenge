# Patient Summary

        **Patient:** Adria871 Ankunding277  
        **Workspace:** synthea-demo  
        **Sources:** 3  
        **Canonical facts:** 192  
        **Review items/conflicts:** 4

        ## Recent / representative facts

        | Type | Date | Fact | Value | Sources |
| --- | --- | --- | --- | --- |
| Observation | 2019-03-24T22:51:44-04:00 | Urea Nitrogen | 18.87099499622739 mg/dL | 1 |
| Observation | 2019-03-24T22:51:44-04:00 | Triglycerides | 156.27982796203796 mg/dL | 1 |
| Observation | 2019-03-24T22:51:44-04:00 | Total Cholesterol | 176.3945040832056 mg/dL | 1 |
| Observation | 2019-03-24T22:51:44-04:00 | Sodium | 137.95785158869703 mmol/L | 1 |
| Observation | 2019-03-24T22:51:44-04:00 | Protein [Mass/volume] in Serum or Plasma | 61.097150437097135 g/dL | 1 |
| Observation | 2019-03-24T22:51:44-04:00 | Potassium | 4.118546507376634 mmol/L | 1 |
| Observation | 2019-03-24T22:51:44-04:00 | Low Density Lipoprotein Cholesterol | 119.41047962688698 mg/dL | 1 |
| Observation | 2019-03-24T22:51:44-04:00 | High Density Lipoprotein Cholesterol | 54.520528147734204 mg/dL | 1 |
| Observation | 2019-03-24T22:51:44-04:00 | Glucose | 94.72057541618341 mg/dL | 1 |
| Observation | 2019-03-24T22:51:44-04:00 | Glomerular filtration rate/1.73 sq M.predicted | 86.3958917280481 mL/min | 1 |
| Observation | 2019-03-24T22:51:44-04:00 | Globulin [Mass/volume] in Serum by calculation | 2.959164202052591 g/L | 1 |
| Observation | 2019-03-24T22:51:44-04:00 | Creatinine | 2.5226746533976074 mg/dL | 1 |

        ## Missing information signals

        - No allergy list facts found in packaged sources.

        ## Notes

        This summary is generated from structured package evidence. It should be reviewed by a clinician before medical use.
