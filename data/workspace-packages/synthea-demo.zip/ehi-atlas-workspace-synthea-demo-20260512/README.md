# EHI Atlas Portable Workspace — synthea-demo

This package is a patient-owned evidence workspace. It is designed to be inspected by humans and used by tools. It is not a replacement for clinical judgment.

## What is included

- Source inventory and prepared source bundles
- Canonical clinical facts
- Provenance and source contribution maps
- Conflicts and missing-information signals
- Agent-ready context packets
- Clinician/patient exports
- A tiny CLI for local inspection

## Quick start

```bash
python cli/atlas_workspace.py manifest
python cli/atlas_workspace.py sources
python cli/atlas_workspace.py facts --type Observation
python cli/atlas_workspace.py missing
python cli/atlas_workspace.py packet patient-summary
python cli/atlas_workspace.py packet preop-review
```

## Using this package with a coding agent

Unzip this archive, `cd` into the directory, and open Claude Code (or any
agent that can read the local filesystem). The agent should read
`AGENT-INSTRUCTIONS.md` first; that file directs it to the structured
evidence and the context packet that matches its task.

## Privacy

Demo data: `True`. Contains PHI flag: `False`.
Review all contents before sharing.
