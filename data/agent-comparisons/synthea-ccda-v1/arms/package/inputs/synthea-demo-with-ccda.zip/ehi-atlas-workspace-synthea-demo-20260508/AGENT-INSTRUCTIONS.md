# Instructions for agents using this package

1. Read `MANIFEST.json` first.
2. Prefer structured evidence in `evidence/` and `packets/` before inspecting raw/prepared source files.
3. Cite `source_refs` or `provenance_refs` for important clinical claims.
4. Use `evidence/missing-information.json` to disclose gaps.
5. Use `evidence/conflicts.json` to disclose unresolved or ambiguous facts.
6. Do not invent unsupported clinical facts.
7. If raw files are included, use them to verify or investigate; do not discard the structured evidence layer.
8. This is not medical advice. Recommend clinician review for medical decisions.
