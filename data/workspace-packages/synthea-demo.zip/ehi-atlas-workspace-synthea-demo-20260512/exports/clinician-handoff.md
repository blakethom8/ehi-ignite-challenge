# Clinician Handoff

| Type | Date | Fact | Value | Evidence |
| --- | --- | --- | --- | --- |
| Observation | 2019-03-24T22:51:44-04:00 | Urea Nitrogen | 18.87099499622739 mg/dL | prov-0142-01 |
| Observation | 2019-03-24T22:51:44-04:00 | Triglycerides | 156.27982796203796 mg/dL | prov-0107-01 |
| Observation | 2019-03-24T22:51:44-04:00 | Total Cholesterol | 176.3945040832056 mg/dL | prov-0099-01 |
| Observation | 2019-03-24T22:51:44-04:00 | Sodium | 137.95785158869703 mmol/L | prov-0117-01 |
| Observation | 2019-03-24T22:51:44-04:00 | Protein [Mass/volume] in Serum or Plasma | 61.097150437097135 g/dL | prov-0109-01 |
| Observation | 2019-03-24T22:51:44-04:00 | Potassium | 4.118546507376634 mmol/L | prov-0140-01 |
| Observation | 2019-03-24T22:51:44-04:00 | Low Density Lipoprotein Cholesterol | 119.41047962688698 mg/dL | prov-0081-01 |
| Observation | 2019-03-24T22:51:44-04:00 | High Density Lipoprotein Cholesterol | 54.520528147734204 mg/dL | prov-0094-01 |
| Observation | 2019-03-24T22:51:44-04:00 | Glucose | 94.72057541618341 mg/dL | prov-0102-01 |
| Observation | 2019-03-24T22:51:44-04:00 | Glomerular filtration rate/1.73 sq M.predicted | 86.3958917280481 mL/min | prov-0121-01 |
| Observation | 2019-03-24T22:51:44-04:00 | Globulin [Mass/volume] in Serum by calculation | 2.959164202052591 g/L | prov-0072-01 |
| Observation | 2019-03-24T22:51:44-04:00 | Creatinine | 2.5226746533976074 mg/dL | prov-0123-01 |

## Gaps / review items

- No allergy list facts found in packaged sources.
