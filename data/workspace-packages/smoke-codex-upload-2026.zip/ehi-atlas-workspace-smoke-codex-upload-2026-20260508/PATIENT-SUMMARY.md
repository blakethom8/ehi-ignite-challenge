# Patient Summary

        **Patient:** Synthetic Demo Patient  
        **Workspace:** smoke-codex-upload-2026  
        **Sources:** 1  
        **Canonical facts:** 12  
        **Review items/conflicts:** 0

        ## Recent / representative facts

        | Type | Date | Fact | Value | Sources |
| --- | --- | --- | --- | --- |
| Observation | 2026-02-03T00:00:00 | Urea nitrogen [Mass/volume] in Serum or Plasma | 31.0 mg/dL | 1 |
| Observation | 2026-02-03T00:00:00 | Sodium [Moles/volume] in Serum or Plasma | 137.0 mmol/L | 1 |
| Observation | 2026-02-03T00:00:00 | Potassium [Moles/volume] in Serum or Plasma | 4.8 mmol/L | 1 |
| Observation | 2026-02-03T00:00:00 | Glucose [Mass/volume] in Serum or Plasma | 118.0 mg/dL | 1 |
| Observation | 2026-02-03T00:00:00 | Glomerular filtration rate/1.73 sq M.predicted [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine-based formula (CKD-EPI) | 42.0 mL/min/{1.73_m2} | 1 |
| Observation | 2026-02-03T00:00:00 | Creatinine [Mass/volume] in Serum or Plasma | 1.8 mg/dL | 1 |
| Observation | 2026-02-03 | eGFR | 42.0 mL/min/{1.73_m2} | 1 |
| Observation | 2026-02-03 | Sodium | 137.0 mmol/L | 1 |
| Observation | 2026-02-03 | Potassium | 4.8 mmol/L | 1 |
| Observation | 2026-02-03 | Glucose | 118.0 mg/dL | 1 |
| Observation | 2026-02-03 | Creatinine | 1.8 mg/dL | 1 |
| Observation | 2026-02-03 | BUN | 31.0 mg/dL | 1 |

        ## Missing information signals

        - No allergy list facts found in packaged sources.
- No active medication list facts found in packaged sources.
- No problem list facts found in packaged sources.

        ## Notes

        This summary is generated from structured package evidence. It should be reviewed by a clinician before medical use.
