# Clinician Handoff

| Type | Date | Fact | Value | Evidence |
| --- | --- | --- | --- | --- |
| Observation | 2026-02-03T00:00:00 | Urea nitrogen [Mass/volume] in Serum or Plasma | 31.0 mg/dL | Observation/9ae6d3aee5a7-corrected-lab-report.pdf-1 |
| Observation | 2026-02-03T00:00:00 | Sodium [Moles/volume] in Serum or Plasma | 137.0 mmol/L | Observation/9ae6d3aee5a7-corrected-lab-report.pdf-4 |
| Observation | 2026-02-03T00:00:00 | Potassium [Moles/volume] in Serum or Plasma | 4.8 mmol/L | Observation/9ae6d3aee5a7-corrected-lab-report.pdf-5 |
| Observation | 2026-02-03T00:00:00 | Glucose [Mass/volume] in Serum or Plasma | 118.0 mg/dL | Observation/9ae6d3aee5a7-corrected-lab-report.pdf-0 |
| Observation | 2026-02-03T00:00:00 | Glomerular filtration rate/1.73 sq M.predicted [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine-based formula (CKD-EPI) | 42.0 mL/min/{1.73_m2} | Observation/9ae6d3aee5a7-corrected-lab-report.pdf-3 |
| Observation | 2026-02-03T00:00:00 | Creatinine [Mass/volume] in Serum or Plasma | 1.8 mg/dL | Observation/9ae6d3aee5a7-corrected-lab-report.pdf-2 |
| Observation | 2026-02-03 | eGFR | 42.0 mL/min/{1.73_m2} | prov-0003-01 |
| Observation | 2026-02-03 | Sodium | 137.0 mmol/L | prov-0006-01 |
| Observation | 2026-02-03 | Potassium | 4.8 mmol/L | prov-0005-01 |
| Observation | 2026-02-03 | Glucose | 118.0 mg/dL | prov-0004-01 |
| Observation | 2026-02-03 | Creatinine | 1.8 mg/dL | prov-0002-01 |
| Observation | 2026-02-03 | BUN | 31.0 mg/dL | prov-0001-01 |

## Gaps / review items

- No allergy list facts found in packaged sources.
- No active medication list facts found in packaged sources.
- No problem list facts found in packaged sources.
