# EHI Atlas Portable Workspace — smoke-codex-upload-2026

This package is a patient-owned evidence workspace. It is designed to be inspected by humans and used by tools. It is not a replacement for clinical judgment.

## What is included

- Source inventory and prepared source bundles
- Canonical clinical facts
- Provenance and source contribution maps
- Conflicts and missing-information signals
- Agent-ready context packets
- Clinician/patient exports
- A tiny CLI for local inspection

## Quick start

```bash
python cli/atlas_workspace.py manifest
python cli/atlas_workspace.py sources
python cli/atlas_workspace.py facts --type Observation
python cli/atlas_workspace.py missing
python cli/atlas_workspace.py packet second-opinion
```

## Privacy

Demo data: `True`. Contains PHI flag: `False`.
Review all contents before sharing.
