#!/usr/bin/env python3
"""Tiny CLI for an unpacked EHI Atlas workspace package."""
from __future__ import annotations
import argparse, json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def load(rel):
    return json.loads((ROOT / rel).read_text())

def cmd_manifest(args):
    print(json.dumps(load('MANIFEST.json'), indent=2))

def cmd_sources(args):
    for s in load('sources/sources.json')['sources']:
        print(f"{s['source_id']}\t{s.get('kind','')}\t{s.get('label','')}")

def cmd_facts(args):
    facts = load('evidence/canonical-facts.json')['facts']
    q = (args.search or '').lower()
    typ = args.type
    for f in facts:
        if typ and f.get('resource_type') != typ: continue
        hay = json.dumps(f).lower()
        if q and q not in hay: continue
        print(f"{f['fact_id']}\t{f.get('resource_type','')}\t{f.get('date','')}\t{f.get('display','')}\t{f.get('value','')}")

def cmd_provenance(args):
    for p in load('evidence/provenance.json')['provenance']:
        if p.get('fact_id') == args.fact_id or p.get('provenance_id') == args.fact_id:
            print(json.dumps(p, indent=2))

def cmd_conflicts(args):
    print(json.dumps(load('evidence/conflicts.json'), indent=2))

def cmd_missing(args):
    print(json.dumps(load('evidence/missing-information.json'), indent=2))

def cmd_packet(args):
    name = args.name if args.name.endswith('.context.json') else f"{args.name}.context.json"
    print((ROOT / 'packets' / name).read_text())

def main():
    ap = argparse.ArgumentParser(description='Inspect an EHI Atlas workspace package')
    sub = ap.add_subparsers(dest='cmd', required=True)
    sub.add_parser('manifest').set_defaults(func=cmd_manifest)
    sub.add_parser('sources').set_defaults(func=cmd_sources)
    p = sub.add_parser('facts'); p.add_argument('--type'); p.add_argument('--search'); p.set_defaults(func=cmd_facts)
    p = sub.add_parser('provenance'); p.add_argument('fact_id'); p.set_defaults(func=cmd_provenance)
    sub.add_parser('conflicts').set_defaults(func=cmd_conflicts)
    sub.add_parser('missing').set_defaults(func=cmd_missing)
    p = sub.add_parser('packet'); p.add_argument('name'); p.set_defaults(func=cmd_packet)
    args = ap.parse_args(); args.func(args)
if __name__ == '__main__': main()
